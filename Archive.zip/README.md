# Zaluea
This is an official proxy of [Zaluea Network](https://discord.gg/8SDaUugBqu).

## Games
So far there is only one game. More will be added soon.

## Credits
Zaluea uses [Ultraviolet](https://github.com/titaniumnetwork-dev/Ultraviolet)
